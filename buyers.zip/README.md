# bare-nodejs-for-ecs-deployment

A base NodeJS implementation to quickly verify the integration of the application to AWS RDS and AWS Elasticache Redis.
